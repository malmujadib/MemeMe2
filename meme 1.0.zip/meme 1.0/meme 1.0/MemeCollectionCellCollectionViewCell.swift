//
//  MemeCollectionCellCollectionViewCell.swift
//  meme 1.0
//
//  Created by Mohammed Mujadib on 05/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import UIKit

class MemeCollectionCellCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
