//
//  MemeTableVC.swift
//  meme 1.0
//
//  Created by Mohammed Mujadib on 29/09/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
import UIKit
class MemeTableVC: UIViewController, UITableViewDelegate, UITableViewDataSource{

    @IBOutlet weak var tableView: UITableView!


 var memes = [Meme] ()

 override func viewDidLoad() {
    
    super.viewDidLoad()
    tableView.delegate = self
    tableView.dataSource = self
    tableView.tableFooterView = UIView()
}

 override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    memes = appDelegate.memes
    tableView.reloadData()
}

 func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
   
    return memes.count
}

 func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {let cell = tableView.dequeueReusableCell(withIdentifier: "cell")!
    
    let memedimge = (UIApplication.shared.delegate as! AppDelegate).memes[(indexPath as NSIndexPath).row]
    cell.imageView?.image = memedimge.memedImage
    cell.textLabel?.text = "\(memedimge.topText) ... \(memedimge.bottomText) "
    return cell
}

 func tableView(_ tableView: UITableView, didSelectRowAt indexPath:IndexPath) {
 
    let memes = (UIApplication.shared.delegate as! AppDelegate).memes
 let memeDetails = self.storyboard?.instantiateViewController (withIdentifier: "MemeDetails") as! MemeDetails
    memeDetails.meme = memes[(indexPath as NSIndexPath).row]
    memeDetails.meme = memes[indexPath.row]
    navigationController!.pushViewController(memeDetails, animated: true)
}
    
    
}
