//
//  MemeCollectionVC.swift
//  meme 1.0
//
//  Created by Mohammed Mujadib on 29/09/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
import UIKit
class MemeCollectionVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var memeCollection: UICollectionView!
    var memes = [Meme]()
   
    
    override func viewDidLoad(){
        super.viewDidLoad()
        memeCollection.delegate = self
        memeCollection.dataSource = self
        
   
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
         memes = appDelegate.memes
        memeCollection?.reloadData()
    }
  
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int ) ->Int {
    
        return memes.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = memeCollection.dequeueReusableCell(withReuseIdentifier: "memeCell", for: indexPath) as! MemeCollectionCellCollectionViewCell
        cell.imageView.image = memes[indexPath.row].memedImage
          return cell
               
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath:IndexPath) {

           let memeDetail = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetails") as! MemeDetails
            memeDetail.meme = memes[indexPath.row]
            self.navigationController!.pushViewController(memeDetail, animated: true)
       }
    


}
