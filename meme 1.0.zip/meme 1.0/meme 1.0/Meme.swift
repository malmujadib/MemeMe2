//
//  Meme.swift
//  meme 1.0
//
//  Created by Mohammed Mujadib on 29/09/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
import UIKit
struct Meme {
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memedImage: UIImage
    
}
